var	thRoot="<absolute-path-to-resources-directory>";		// In an exploded war, this is usually webapp root
var	thPath="<relative-path-from-resources-to-templates>";		// In an exploded war, this is usually WEB-INF/<some-path>
var     thDebug = true;

var	thVars = [
	    ["currentUser",	"#{ 'gravatar': 'ffa96040bb4211cad1c66f385d8cb77b', 'login': 'duyhai', 'firstName': 'Duyhai', 'lastName': 'DOAN' }"]
	];
