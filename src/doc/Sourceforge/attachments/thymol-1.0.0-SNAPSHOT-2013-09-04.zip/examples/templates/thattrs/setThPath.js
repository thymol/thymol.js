var	thRoot="<absolute-path-to-resources-directory>";		// In an exploded war, this is usually webapp root
var	thPath="<relative-path-from-resources-to-templates>";		// In an exploded war, this is usually WEB-INF/<some-path>
var     thDebug = true;
