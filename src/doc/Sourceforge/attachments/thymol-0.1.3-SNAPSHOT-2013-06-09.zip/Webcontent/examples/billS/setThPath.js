var	thRoot="/home/jim/Project/thymol/distr/Webcontent";
var	thPath="examples/billS";
