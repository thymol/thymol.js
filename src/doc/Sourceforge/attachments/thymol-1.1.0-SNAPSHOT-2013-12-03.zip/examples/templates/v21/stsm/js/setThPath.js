var	thRoot="<absolute-path-to-resources-directory>";		// In an exploded war, this is usually webapp root, for a file based system set this to the stsm directory one level up from this file
var	thPath="<relative-path-from-resources-to-templates>";		// In an exploded war, this is usually WEB-INF/<some-path>, for a file based system set this to blank ( var thPath=""; )
var     thDebug = true;
var     thShowNullOperands=true;
