 Before this example will work correctly with Thymol you need to:
 
 1. Change the paths in the setThPath.js to the correct values for your deployment.
 2. Copy the required jquery js and css files to the appropriate places for your deployment (css and js resource directories).
